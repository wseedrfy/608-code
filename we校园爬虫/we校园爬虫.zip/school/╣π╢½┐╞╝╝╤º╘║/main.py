import requests
from school.广东科技学院.code.code import code_ocr
from school.广东科技学院.login.login import login
from school.广东科技学院.data.data import data


def login_GKY(username, password):
    session = requests.session()
    code, cookie, nowTime = code_ocr(session)
    return login(session, username, password, code, nowTime)


def getData_GKY(username, password):
    session = requests.session()
    code, cookie, nowTime = code_ocr(session)
    msg = login(session, username, password, code, nowTime)
    if msg != {"msg": 'welcome'}:
        return msg
    return data(session)
